# OASIS Coder AI

AI-powered OASIS assessment reviewer — flags ICD-10 errors, clinical logic
issues, and HIPAA/CMS compliance risks using Gemini 2.0 Flash.

---

## Setup in VS Code

### 1. Open the project

```
File → Open Folder → select the oasis-coder folder
```

### 2. Create a virtual environment

Open the VS Code terminal (Ctrl+` ) and run:

```bash
python -m venv venv
```

Activate it:
- **Windows:**  `venv\Scripts\activate`
- **Mac/Linux:** `source venv/bin/activate`

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Add your Gemini API key

Edit the `.env` file:

```
GEMINI_API_KEY=your_actual_key_here
FLASK_SECRET_KEY=pick_any_random_string
```

Get a free key at: https://aistudio.google.com/app/apikey

### 5. Run the app

```bash
python app.py
```

Open your browser at: **http://localhost:5000**

---

## Project structure

```
oasis-coder/
├── app.py                  # Flask backend + Gemini API call
├── requirements.txt        # Python dependencies
├── .env                    # API keys (never commit this)
├── templates/
│   └── index.html          # Main page
└── static/
    ├── css/style.css       # Styles
    └── js/app.js           # Frontend logic
```

---

## How it works

1. Coder drops an OASIS assessment PDF into the browser
2. Flask backend sends it to Gemini 2.0 Flash as a native PDF document
3. Gemini reads the full assessment against the embedded OASIS-E1 + ICD-10 rules
4. Returns structured JSON with flagged issues, suggested ICD-10 corrections,
   severity scores, and compliance warnings
5. Frontend renders the report as a colour-coded review

---

## Moving to production

- Switch the Gemini endpoint to **Vertex AI** (covers HIPAA BAA)
- Add user authentication before deploying to a server
- Consider adding the OASIS-E1 manual PDF as a second document in the API
  call for higher accuracy
- Log all reviews to a database for audit trail purposes
