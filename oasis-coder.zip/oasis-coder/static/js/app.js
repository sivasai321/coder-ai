// ── State ────────────────────────────────────────────────────────────────────
let selectedFile = null;

// ── DOM refs ─────────────────────────────────────────────────────────────────
const fileInput   = document.getElementById('fileInput');
const dropzone    = document.getElementById('dropzone');
const filenameEl  = document.getElementById('filename');
const analyzeBtn  = document.getElementById('analyzeBtn');
const loader      = document.getElementById('loader');
const loaderText  = document.getElementById('loaderText');
const results     = document.getElementById('results');
const errorBanner = document.getElementById('errorBanner');

// ── File handling ─────────────────────────────────────────────────────────────
fileInput.addEventListener('change', () => handleFile(fileInput.files[0]));

dropzone.addEventListener('dragover',  e => { e.preventDefault(); dropzone.classList.add('drag'); });
dropzone.addEventListener('dragleave', () => dropzone.classList.remove('drag'));
dropzone.addEventListener('drop', e => {
  e.preventDefault(); dropzone.classList.remove('drag');
  const f = e.dataTransfer.files[0];
  if (f && f.type === 'application/pdf') handleFile(f);
  else showError('Please drop a PDF file.');
});

function handleFile(file) {
  if (!file) return;
  selectedFile = file;
  filenameEl.textContent = '✓ ' + file.name;
  filenameEl.style.display = 'block';
  analyzeBtn.disabled = false;
}

// ── Health check ──────────────────────────────────────────────────────────────
async function checkHealth() {
  const dot  = document.querySelector('.status-dot');
  const text = document.getElementById('statusText');
  text.textContent = 'Checking…';
  try {
    const res  = await fetch('/api/health');
    const data = await res.json();
    if (data.gemini_key_set) {
      dot.classList.remove('err');
      text.textContent = 'Gemini 2.0 Flash ✓';
    } else {
      dot.classList.add('err');
      text.textContent = 'No API key';
    }
  } catch {
    dot.classList.add('err');
    text.textContent = 'Server error';
  }
}

// ── Loader messages ───────────────────────────────────────────────────────────
const LOADER_MESSAGES = [
  'Reading assessment PDF…',
  'Cross-referencing OASIS-E1 manual…',
  'Validating ICD-10 codes…',
  'Checking clinical logic…',
  'Scanning for compliance risks…',
  'Generating report…',
];
let loaderInterval;

function startLoader() {
  let i = 0;
  loaderText.textContent = LOADER_MESSAGES[0];
  loaderInterval = setInterval(() => {
    i = (i + 1) % LOADER_MESSAGES.length;
    loaderText.textContent = LOADER_MESSAGES[i];
  }, 2200);
}
function stopLoader() { clearInterval(loaderInterval); }

// ── Analyze ───────────────────────────────────────────────────────────────────
analyzeBtn.addEventListener('click', analyze);

async function analyze() {
  if (!selectedFile) return;

  hideError();
  results.innerHTML = '';
  loader.classList.add('active');
  analyzeBtn.disabled = true;
  startLoader();

  const formData = new FormData();
  formData.append('pdf', selectedFile);

  const apiKey = document.getElementById('apiKeyInput').value.trim();
  if (apiKey) formData.append('api_key', apiKey);

  try {
    const res  = await fetch('/api/analyze', { method: 'POST', body: formData });
    const data = await res.json();

    stopLoader();
    loader.classList.remove('active');
    analyzeBtn.disabled = false;

    if (!res.ok || data.error) {
      showError(data.error || 'Unknown error from server.');
      return;
    }

    renderResults(data.report, data.raw);

  } catch (err) {
    stopLoader();
    loader.classList.remove('active');
    analyzeBtn.disabled = false;
    showError('Network error: ' + err.message);
  }
}

// ── Render results ─────────────────────────────────────────────────────────────
function renderResults(r, rawJson) {
  const riskColor = { high: 'red', medium: 'amber', low: 'green' };

  let html = `
    <div class="summary-bar">
      <div class="summary-card red">
        <div class="s-label">High severity</div>
        <div class="s-val">${r.summary.high_severity}</div>
      </div>
      <div class="summary-card amber">
        <div class="s-label">Medium severity</div>
        <div class="s-val">${r.summary.medium_severity}</div>
      </div>
      <div class="summary-card blue">
        <div class="s-label">Low severity</div>
        <div class="s-val">${r.summary.low_severity}</div>
      </div>
      <div class="summary-card ${riskColor[r.overall_risk] || 'green'}">
        <div class="s-label">Overall risk</div>
        <div class="s-val">${(r.overall_risk || 'N/A').toUpperCase()}</div>
      </div>
    </div>`;

  // Issues
  const issues = r.issues || [];
  html += `<div class="sec-head"><h2>Issues found (${issues.length})</h2><div class="sec-line"></div></div>`;

  if (issues.length === 0) {
    html += `<div class="issue-card sev-low" style="text-align:center;padding:32px">
      <div style="color:var(--accent);font-family:var(--mono);font-size:13px">✓ No issues detected</div>
    </div>`;
  } else {
    for (const issue of issues) {
      html += `
        <div class="issue-card sev-${issue.severity}">
          <div class="issue-top">
            <div>
              <div class="issue-mitem">${esc(issue.m_item || '')}</div>
              <div class="issue-title">${esc(issue.title)}</div>
            </div>
            <span class="sev-badge badge-${issue.severity}">${issue.severity}</span>
          </div>
          <div class="issue-explain">${esc(issue.explanation)}</div>`;

      if (issue.icd_found || issue.icd_suggested) {
        html += `<div class="icd-row">`;
        if (issue.icd_found) {
          html += `<span class="icd-tag icd-found">✗ ${esc(issue.icd_found)}${issue.icd_found_description ? ' — ' + esc(issue.icd_found_description) : ''}</span>`;
        }
        if (issue.icd_found && issue.icd_suggested) {
          html += `<span class="icd-arrow">→</span>`;
        }
        if (issue.icd_suggested) {
          html += `<span class="icd-tag icd-suggested">✓ ${esc(issue.icd_suggested)}${issue.icd_suggested_description ? ' — ' + esc(issue.icd_suggested_description) : ''}</span>`;
        }
        html += `</div>`;
      }
      html += `</div>`;
    }
  }

  // Compliance warnings
  const warnings = r.compliance_warnings || [];
  if (warnings.length > 0) {
    html += `<div class="sec-head"><h2>Compliance warnings (${warnings.length})</h2><div class="sec-line"></div></div>`;
    for (const w of warnings) {
      html += `
        <div class="compliance-card">
          <div class="c-title">⚠ ${esc(w.title)}</div>
          <div class="c-body">${esc(w.detail)}</div>
        </div>`;
    }
  }

  // Raw JSON
  html += `
    <button class="json-toggle" onclick="toggleJson(this)">Show raw JSON</button>
    <pre class="json-block" id="jsonBlock">${esc(rawJson)}</pre>`;

  results.innerHTML = html;
  results.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function toggleJson(btn) {
  const block = document.getElementById('jsonBlock');
  block.classList.toggle('open');
  btn.textContent = block.classList.contains('open') ? 'Hide raw JSON' : 'Show raw JSON';
}

function showError(msg) {
  errorBanner.textContent = '⚠  ' + msg;
  errorBanner.classList.add('visible');
}

function hideError() {
  errorBanner.classList.remove('visible');
}

function esc(str) {
  return String(str || '')
    .replace(/&/g,'&amp;')
    .replace(/</g,'&lt;')
    .replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}

// Auto health check on load
checkHealth();
