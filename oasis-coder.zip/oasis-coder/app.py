import os
import json
import base64
import re
from flask import Flask, request, jsonify, render_template, session
from dotenv import load_dotenv
import google.generativeai as genai

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "dev-secret-key")

# ── Gemini setup ────────────────────────────────────────────────────────────
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

# ── System prompt ────────────────────────────────────────────────────────────
SYSTEM_PROMPT = """You are an expert home health medical coder with deep knowledge of:
- OASIS-E1 item guidance and CMS regulations
- ICD-10-CM coding conventions and home health coding guidelines
- HIPAA compliance requirements for home health agencies
- Common errors nurses make when completing OASIS assessments under time pressure
  (e.g. inconsistent skip logic, non-specific codes, diagnosis/clinical-finding mismatches)

Your task is to review the uploaded OASIS assessment PDF and identify:
1. Logical inconsistencies between clinical findings and selected responses
   (e.g. M1400 dyspnea marked "not present" when diagnoses include COPD)
2. ICD-10 codes that are invalid, insufficiently specific, not appropriate for
   home health, or inconsistent with OASIS item responses
3. OASIS-E1 rule violations (skip logic errors, invalid response combinations,
   missing required items)
4. HIPAA/CMS compliance risks that could trigger audit flags or claim denials

Return ONLY a valid JSON object with NO markdown fences, NO explanation outside
the JSON, in exactly this structure:

{
  "patient_id": "redacted or from document",
  "assessment_date": "date if found, else null",
  "overall_risk": "high|medium|low",
  "summary": {
    "total_issues": 0,
    "high_severity": 0,
    "medium_severity": 0,
    "low_severity": 0,
    "compliance_flags": 0
  },
  "issues": [
    {
      "id": "ISS-001",
      "m_item": "M1400",
      "title": "Short description of the issue",
      "severity": "high|medium|low",
      "explanation": "Clear explanation citing OASIS-E1 guidance or ICD-10 rule",
      "icd_found": "code or null",
      "icd_found_description": "description or null",
      "icd_suggested": "corrected code or null",
      "icd_suggested_description": "description or null",
      "category": "logic_error|icd_invalid|icd_specificity|skip_logic|missing_item|other"
    }
  ],
  "compliance_warnings": [
    {
      "id": "CMP-001",
      "title": "Short compliance warning title",
      "detail": "Explanation of HIPAA/CMS risk and recommended action"
    }
  ]
}

Be thorough. Flag every issue. Prioritise clinical logic errors and ICD-10
specificity issues — they have direct reimbursement impact."""


# ── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/analyze", methods=["POST"])
def analyze():
    # Allow per-request API key override (useful when .env key is not set)
    api_key = request.form.get("api_key") or GEMINI_API_KEY
    if not api_key:
        return jsonify({"error": "No Gemini API key provided. Add it to .env or paste it in the UI."}), 400

    pdf_file = request.files.get("pdf")
    if not pdf_file:
        return jsonify({"error": "No PDF file uploaded."}), 400

    if not pdf_file.filename.lower().endswith(".pdf"):
        return jsonify({"error": "Only PDF files are supported."}), 400

    pdf_bytes = pdf_file.read()
    if len(pdf_bytes) > 20 * 1024 * 1024:  # 20 MB guard
        return jsonify({"error": "PDF is too large (max 20 MB)."}), 400

    # Configure key for this request
    genai.configure(api_key=api_key)

    try:
        model = genai.GenerativeModel(
            model_name="gemini-2.0-flash",
            system_instruction=SYSTEM_PROMPT,
        )

        pdf_part = {
            "inline_data": {
                "mime_type": "application/pdf",
                "data": base64.b64encode(pdf_bytes).decode("utf-8"),
            }
        }

        response = model.generate_content(
            [pdf_part, "Please review this OASIS assessment and return the JSON report as instructed."],
            generation_config=genai.GenerationConfig(
                temperature=0.1,
                max_output_tokens=8192,
            ),
        )

        raw = response.text.strip()

        # Strip markdown fences if the model adds them
        raw = re.sub(r"^```json\s*", "", raw)
        raw = re.sub(r"\s*```$", "", raw)

        report = json.loads(raw)
        return jsonify({"success": True, "report": report, "raw": raw})

    except json.JSONDecodeError as e:
        return jsonify({"error": f"Model returned invalid JSON: {e}", "raw": raw}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/health")
def health():
    return jsonify({"status": "ok", "gemini_key_set": bool(GEMINI_API_KEY)})


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("\n  OASIS Coder AI")
    print("  Running at http://localhost:5000\n")
    app.run(debug=True, port=5000)
